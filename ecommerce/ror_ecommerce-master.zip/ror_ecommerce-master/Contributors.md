In no specific order the following have contributed to RoR ecommerce.

* João Martins
* Oren Golan
* Yury Velikanau
* Torsten Rüger
* Dean Perry
* Denis Peplin
* Daniel Konishi
* Robert Mitwicki
* Jason Kim
* Kori Roys
* TopperH
