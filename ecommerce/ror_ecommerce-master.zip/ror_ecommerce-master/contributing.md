I'm hoping you know the drill.

* Fork the project
* Make some fixes
* submit a pull request

If accepted ask to be added as a contributor on github and I'll give you access.  Going by the honor rule that you only push changes that aren't debatable.

Example rejection:

1)  Converting to HAML

Even though haml is nice not everyone knows haml.  To make the project easiest for anyone to contribute lets stick with ERB.

Example contribution:

* UI improvements
* Bug fixes
* Changes that have been discussed in issues and agreed should be worked on.
