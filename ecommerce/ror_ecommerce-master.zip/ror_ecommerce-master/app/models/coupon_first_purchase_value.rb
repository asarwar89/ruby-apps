class CouponFirstPurchaseValue < CouponValue
  include CouponFirstPurchase
end
