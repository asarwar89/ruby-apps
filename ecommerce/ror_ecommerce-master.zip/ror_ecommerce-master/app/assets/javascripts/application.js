//= require jquery
//= require jquery-ui
//= require jquery_ujs
//= require_tree  ./jquery
//= require_tree  ./layout
//= require foundation
$(function(){ $(document).foundation(); });
