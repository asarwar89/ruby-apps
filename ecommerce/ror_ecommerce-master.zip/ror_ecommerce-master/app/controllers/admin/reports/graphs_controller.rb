class Admin::Reports::GraphsController < Admin::Reports::BaseController
  layout 'admin_charts'
  def index

  end

  def show
    #@graphs = Graphs.find(params[:id])
  end

  private

end
