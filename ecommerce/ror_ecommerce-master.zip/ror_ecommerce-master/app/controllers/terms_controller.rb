class TermsController < ApplicationController
  #caches_page :index
  def index

  end
end
