# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hadean::Application.config.secret_token = '26f7f2c0812bb8cdc0c098fd4e74fb82641f6317ff79ca8048e38bdd1f83690e6deaa6d4edffe79992da57492c0a73a09959ab324e9b8cbacb6c02487f97bcc5'
Hadean::Application.config.secret_key_base = 'MyNewRORecommerceApp'
