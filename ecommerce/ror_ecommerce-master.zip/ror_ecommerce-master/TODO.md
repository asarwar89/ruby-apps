## This is a random list of thoughts that I would like todo.

add tax and not adding tax

global flag for VAT

VAT tax calculation:
100E (1/(1 - tax%))

---------

Github Wiki is git based

Pages in github
rubyforge subdomain
look in creating my own subdomain in github

Versions

Add yard docs to github

browser admin lists don't look right in Chrome 10.6

rake task

rake db:test:prepare  blows up on SQLite

b2b  (invoice)